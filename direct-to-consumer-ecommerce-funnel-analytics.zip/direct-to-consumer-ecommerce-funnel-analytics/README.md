\# Direct-to-Consumer E-Commerce Funnel Analytics

\#\# 1\. Choose a Business-Relevant Analytics Project

\*\*Project:\*\*  
Direct-to-Consumer E-Commerce Funnel Analytics

This project analyzes an e-commerce funnel dataset to understand where users drop before purchase, which traffic sources bring the highest-quality users, and what actions can help improve sales performance.

The project is built as an end-to-end analytics workflow:

\`\`\`text  
raw data → data cleaning → KPI calculation → funnel analysis → segment analysis → export tables → dashboard → business recommendations  
\`\`\`

\---

\#\# 2\. Define the Business Problem

The business has traffic, product views, cart activity, checkout starts, and purchases, but it is unclear where potential revenue is being lost.

\*\*Main business problem:\*\*

\> Where does the business lose potential revenue, and what should be optimized first?

The analysis focuses on identifying weak points in the customer journey and translating them into practical optimization opportunities.

\---

\#\# 3\. Define Stakeholders and Expected Decisions

\#\#\# Stakeholders

\* CEO / Founder  
\* E-commerce Manager  
\* Marketing Manager  
\* Performance Marketing Specialist  
\* UX / CRO Specialist

\#\#\# Expected Decisions

The analysis should help stakeholders decide:

\* Which funnel stage should be optimized first?  
\* Which channels bring traffic volume, and which bring quality?  
\* Which traffic sources generate the highest revenue?  
\* Is mobile experience a growth opportunity?  
\* Are returning users more valuable than new users?  
\* Should discounts be used more strategically?  
\* What A/B tests or UX improvements should be prioritized?

\---

\#\# 4\. Find and Review the Dataset

\*\*Dataset:\*\*  
Direct-to-Consumer E-Commerce Funnel Dataset

The dataset contains e-commerce funnel, traffic, user, device, discount, and revenue-related data.

\#\#\# Main Fields

\* \`channel\`  
\* \`campaign\_type\`  
\* \`device\`  
\* \`user\_type\`  
\* \`region\`  
\* funnel stage fields  
\* \`order\_value\`  
\* \`revenue\`

The main funnel includes:

\`\`\`text  
Session → Product View → Add to Cart → Checkout Started → Purchase  
\`\`\`

\---

\#\# 5\. Define Project Goal and Analytical Questions

\#\#\# Project Goal

The goal of this project is to analyze the e-commerce funnel in order to identify drop-off points, high-value traffic sources, and business opportunities for improving conversion and revenue.

\#\#\# Analytical Questions

1\. Where do users drop off in the funnel?  
2\. Which channel brings the most traffic?  
3\. Which channel brings the highest revenue?  
4\. Which channel has the best revenue per session?  
5\. Which channel has the strongest purchase conversion rate?  
6\. Does mobile traffic have growth potential?  
7\. Are returning users more valuable than new users?  
8\. How do discounts affect conversion and revenue?  
9\. How does monthly performance change over time?  
10\. What should the business optimize first?

\---

\#\# 6\. Create KPI Framework

The project uses a KPI framework that connects funnel performance, revenue, and business decision-making.

\#\#\# Core KPIs

\* Sessions  
\* Product views  
\* Add to cart  
\* Checkout started  
\* Purchases  
\* Revenue  
\* Product view rate  
\* Add-to-cart rate  
\* Checkout rate  
\* Checkout completion rate  
\* Purchase conversion rate  
\* Funnel drop-off rate  
\* AOV  
\* Revenue per session

\#\#\# Why These KPIs Matter

| KPI                        | Business Meaning                                       |  
| \-------------------------- | \------------------------------------------------------ |  
| \`sessions\`                 | Shows total traffic volume                             |  
| \`product\_views\`            | Shows how many users reached product pages             |  
| \`add\_to\_cart\`              | Shows product interest and buying intent               |  
| \`checkout\_started\`         | Shows how many users moved closer to purchase          |  
| \`purchases\`                | Shows completed transactions                           |  
| \`revenue\`                  | Shows total sales value                                |  
| \`product\_view\_rate\`        | Shows how effectively sessions turn into product views |  
| \`add\_to\_cart\_rate\`         | Shows whether users are interested in the offer        |  
| \`checkout\_rate\`            | Shows how many users continue from cart to checkout    |  
| \`checkout\_completion\_rate\` | Shows how effectively checkout turns into purchases    |  
| \`purchase\_conversion\_rate\` | Shows how effectively traffic converts into customers  |  
| \`funnel\_drop\_off\_rate\`     | Shows where potential revenue is lost                  |  
| \`aov\`                      | Shows average order value                              |  
| \`revenue\_per\_session\`      | Shows the monetary value of each session               |

\---

\#\# 7\. Load Data into Jupyter Notebook

The raw dataset was loaded into Jupyter Notebook for analysis.

The notebook includes:

\* importing Python libraries;  
\* loading the dataset;  
\* previewing the first rows;  
\* checking dataset size;  
\* reviewing data types;  
\* checking missing values;  
\* checking duplicates;  
\* preparing fields for analysis.

Main tools used in the notebook:

\* Python  
\* Pandas  
\* NumPy  
\* Matplotlib  
\* Jupyter Notebook

\---

\#\# 8\. Explore Data Structure

The initial data exploration included:

\* dataset shape;  
\* column names;  
\* data types;  
\* missing values;  
\* duplicate rows;  
\* categorical distributions;  
\* numerical summaries.

The purpose of this step was to understand whether the dataset was reliable enough for funnel and revenue analysis.

\---

\#\# 9\. Create Data Dictionary

A separate data dictionary was prepared to document the fields used in the project.

\#\#\# Output Table

\`\`\`text  
data\_dictionary.csv  
\`\`\`

This table explains the meaning of the main columns used in the analysis and makes the project easier to understand for reviewers, stakeholders, and future users.

\---

\#\# 10\. Check Data Quality

The data quality check focused on:

\* missing values;  
\* duplicate rows;  
\* incorrect data types;  
\* inconsistent categorical values;  
\* funnel logic issues;  
\* revenue and order value consistency.

This step was necessary before calculating business metrics.

\---

\#\# 11\. Clean and Transform Data

After reviewing the raw dataset, the data was cleaned and prepared for analysis.

The cleaning and transformation process included:

\* standardizing column names;  
\* converting date/month fields;  
\* preparing funnel stage fields;  
\* creating binary flags where needed;  
\* checking revenue fields;  
\* preparing clean data for further aggregation.

\#\#\# Output Table

\`\`\`text  
clean\_d2c\_funnel\_data.csv  
\`\`\`

This table contains the cleaned version of the original dataset and is used as the base for further analysis.

\---

\#\# 12\. Create Calculated Fields

Calculated fields were created to support KPI and funnel analysis.

Examples of calculated metrics:

\* product view rate;  
\* add-to-cart rate;  
\* checkout rate;  
\* checkout completion rate;  
\* purchase conversion rate;  
\* drop-off rate;  
\* AOV;  
\* revenue per session.

These calculated fields were then used to create summary tables for dashboarding and reporting.

\---

\#\# 13\. Perform Exploratory Data Analysis

The exploratory data analysis focused on understanding performance across key business dimensions:

\* traffic channel;  
\* device;  
\* user type;  
\* discount usage;  
\* month;  
\* funnel stage.

The goal was not only to describe the data, but to identify business patterns and possible optimization opportunities.

\---

\#\# 14\. Funnel Analysis

The funnel analysis shows how users move through the purchase journey.

\#\#\# Funnel Stages

\`\`\`text  
Sessions → Product Views → Add to Cart → Checkout Started → Purchases  
\`\`\`

The analysis calculates:

\* number of users/sessions at each stage;  
\* conversion between stages;  
\* drop-off between stages;  
\* lost users at each transition.

\#\#\# Output Tables

\`\`\`text  
funnel\_counts.csv  
funnel\_transitions.csv  
\`\`\`

\`funnel\_counts.csv\` shows the number of users or sessions at each funnel stage.

\`funnel\_transitions.csv\` shows stage-by-stage conversion and drop-off rates.

\---

\#\# 15\. Channel Analysis

Channel analysis compares acquisition channels by traffic volume, funnel performance, conversion quality, and revenue.

\#\#\# Business Questions

\* Which channel brings the most sessions?  
\* Which channel generates the most purchases?  
\* Which channel generates the most revenue?  
\* Which channel has the highest purchase conversion rate?  
\* Which channel has the highest revenue per session?  
\* Are high-volume channels also high-quality channels?

\#\#\# Output Table

\`\`\`text  
channel\_summary.csv  
\`\`\`

This table is used for the Channel Performance section of the dashboard.

\---

\#\# 16\. Device Analysis

Device analysis compares performance between device types, such as mobile and desktop.

\#\#\# Business Questions

\* Does mobile traffic convert worse than desktop traffic?  
\* Is mobile generating enough revenue compared to its traffic volume?  
\* Is there a possible mobile UX or checkout issue?  
\* Should mobile optimization be a priority?

\#\#\# Output Table

\`\`\`text  
device\_summary.csv  
\`\`\`

This table is used for the Device Performance section of the dashboard.

\---

\#\# 17\. User Type Analysis

User type analysis compares new and returning users.

\#\#\# Business Questions

\* Are returning users more valuable than new users?  
\* Do returning users convert better?  
\* Should the business invest more in retention?  
\* Are new users dropping too early in the funnel?

\#\#\# Output Table

\`\`\`text  
user\_type\_summary.csv  
\`\`\`

This table is used to evaluate customer behavior by user type.

\---

\#\# 18\. Discount Analysis

Discount analysis evaluates how discount usage affects conversion and revenue.

\#\#\# Business Questions

\* Do discounts increase purchase conversion?  
\* Do discounted users generate higher or lower order value?  
\* Does discounting improve revenue efficiency?  
\* Should discounts be used more selectively?

\#\#\# Output Table

\`\`\`text  
discount\_summary.csv  
\`\`\`

This table is used to compare performance between discounted and non-discounted sessions or purchases.

\---

\#\# 19\. Monthly Analysis

Monthly analysis tracks performance changes over time.

\#\#\# Business Questions

\* Is revenue growing or declining?  
\* Are purchases increasing over time?  
\* Are conversion rates stable?  
\* Are there any unusual monthly changes?  
\* Is there a seasonal trend?

\#\#\# Output Table

\`\`\`text  
monthly\_summary.csv  
\`\`\`

This table is used for monthly trend charts in the dashboard.

\---

\#\# 20\. Overall Metrics Summary

The overall metrics table contains the main high-level KPIs of the project.

\#\#\# Output Table

\`\`\`text  
overall\_metrics.csv  
\`\`\`

This table can be used for KPI cards in Looker Studio.

It includes high-level metrics such as:

\* total sessions;  
\* total product views;  
\* total add-to-cart events;  
\* total checkout starts;  
\* total purchases;  
\* total revenue;  
\* purchase conversion rate;  
\* AOV;  
\* revenue per session.

\---

\#\# 21\. Project Limitations

A separate table was created to document the limitations of the analysis.

\#\#\# Output Table

\`\`\`text  
project\_limitations.csv  
\`\`\`

This table explains what data is missing and how it affects the interpretation of the results.

Examples of limitations:

\* no customer acquisition cost;  
\* no profit margin;  
\* no product-level profitability;  
\* no customer lifetime value;  
\* no A/B test data;  
\* no qualitative user feedback;  
\* no page speed data;  
\* no checkout behavior details.

Because of these limitations, the recommendations should be treated as data-informed hypotheses, not final causal conclusions.

\---

\#\# 22\. Export Tables After Data Cleaning and Analysis

After cleaning, transformation, KPI calculation, and analysis, the following CSV tables were created for reporting and dashboarding.

\#\#\# Final Exported Tables

| File Name                   | Purpose                                              |  
| \--------------------------- | \---------------------------------------------------- |  
| \`clean\_d2c\_funnel\_data.csv\` | Cleaned dataset used as the base for analysis        |  
| \`data\_dictionary.csv\`       | Description of dataset fields and their meaning      |  
| \`overall\_metrics.csv\`       | High-level KPI summary for executive overview        |  
| \`funnel\_counts.csv\`         | Number of sessions/users at each funnel stage        |  
| \`funnel\_transitions.csv\`    | Conversion and drop-off between funnel stages        |  
| \`channel\_summary.csv\`       | Funnel and revenue performance by traffic channel    |  
| \`device\_summary.csv\`        | Funnel and revenue performance by device type        |  
| \`user\_type\_summary.csv\`     | Funnel and revenue performance by user type          |  
| \`discount\_summary.csv\`      | Conversion and revenue performance by discount usage |  
| \`monthly\_summary.csv\`       | Monthly performance trends                           |  
| \`project\_limitations.csv\`   | Project limitations and missing data context         |

These tables are prepared after the data cleaning and analysis process.  
They can be uploaded to Google Sheets as separate tabs and then connected to Looker Studio for dashboard visualization.

\---

\#\# 23\. Looker Studio Dashboard

The exported CSV tables are used as reporting sources for the Looker Studio dashboard.

\#\#\# Dashboard Sections

\* Executive KPI overview  
\* Funnel performance  
\* Funnel drop-off analysis  
\* Channel performance  
\* Device performance  
\* User type comparison  
\* Discount analysis  
\* Monthly trends  
\* Project limitations and next steps

\#\#\# Recommended Data Sources

| Dashboard Section   | Data Source               |  
| \------------------- | \------------------------- |  
| KPI Overview        | \`overall\_metrics.csv\`     |  
| Funnel Overview     | \`funnel\_counts.csv\`       |  
| Funnel Drop-off     | \`funnel\_transitions.csv\`  |  
| Channel Performance | \`channel\_summary.csv\`     |  
| Device Performance  | \`device\_summary.csv\`      |  
| User Type Analysis  | \`user\_type\_summary.csv\`   |  
| Discount Analysis   | \`discount\_summary.csv\`    |  
| Monthly Trends      | \`monthly\_summary.csv\`     |  
| Limitations         | \`project\_limitations.csv\` |

\---

\#\# 24\. Business Insights

The purpose of the analysis is to move from raw data to business insights.

Each insight follows this structure:

\`\`\`text  
Finding → Business meaning → Possible reason → Recommended action  
\`\`\`

Example:

\`\`\`text  
Finding:  
Mobile traffic has a lower purchase conversion rate than desktop.

Business meaning:  
The business may be losing potential revenue from mobile users.

Possible reason:  
Mobile product pages or checkout flow may create friction.

Recommended action:  
Review mobile UX, page speed, product page layout, checkout steps, and payment experience.  
\`\`\`

\---

\#\# 25\. Final Recommendations

The final recommendations should answer the main business question:

\> Where does the business lose potential revenue, and what should be optimized first?

Recommended focus areas:

1\. Optimize the funnel stage with the highest drop-off.  
2\. Review mobile user experience and checkout flow.  
3\. Scale channels with high revenue per session and strong conversion.  
4\. Improve or reconsider low-quality acquisition channels.  
5\. Use discounts more strategically.  
6\. Strengthen retention campaigns if returning users perform better.  
7\. Collect additional data for CAC, ROAS, profit margin, product performance, and customer lifetime value.

\---

\#\# 26\. Project Structure

\`\`\`text  
direct-to-consumer-ecommerce-funnel-analytics/  
│  
├── data/  
│   ├── raw/  
│   │   └── d2c\_funnel\_raw\_data.csv  
│   │  
│   └── processed/  
│       ├── channel\_summary.csv  
│       ├── clean\_d2c\_funnel\_data.csv  
│       ├── data\_dictionary.csv  
│       ├── device\_summary.csv  
│       ├── discount\_summary.csv  
│       ├── funnel\_counts.csv  
│       ├── funnel\_transitions.csv  
│       ├── monthly\_summary.csv  
│       ├── overall\_metrics.csv  
│       ├── project\_limitations.csv  
│       └── user\_type\_summary.csv  
│  
├── notebooks/  
│   └── d2c\_ecommerce\_funnel\_analysis.ipynb  
│  
├── dashboard/  
│   ├── looker\_studio\_dashboard\_link.txt  
│   └── dashboard\_screenshot.png  
│  
├── README.md  
└── requirements.txt  
\`\`\`

\---

\#\# 27\. Tools Used

\* Python  
\* Pandas  
\* NumPy  
\* Matplotlib  
\* Jupyter Notebook  
\* Google Sheets  
\* Looker Studio  
\* GitHub

\---

\#\# 28\. Final Deliverables

This project includes:

\* cleaned dataset;  
\* data dictionary;  
\* Jupyter Notebook with analysis;  
\* calculated KPI tables;  
\* funnel analysis tables;  
\* segment summary tables;  
\* Looker Studio dashboard;  
\* business insights;  
\* final recommendations;  
\* GitHub project documentation.

\---

\#\# 29\. About This Project

This project was created as a portfolio case to demonstrate practical data analytics skills, business thinking, KPI design, data cleaning, dashboard preparation, and the ability to translate raw data into actionable business recommendations.

The main idea of the project is not only to create charts, but to show the full analytical process:

\`\`\`text  
business problem → data preparation → KPI framework → analysis → insights → recommendations → dashboard  
\`\`\`